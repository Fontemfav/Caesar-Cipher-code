import os

def welcome():
    print("Welcome to the Caesar Cipher.")
    print("This program encrypts and decrypts text using Caesar Cipher.")

def get_mode():
    while True:
        mode = input("Would you like to encrypt (e) or decrypt (d)?: ").lower()
        if mode in ('e', 'd'):
            return mode
        print("Invalid mode. Please enter 'e' for encrypt or 'd' for decrypt.")

def get_message():
    return input("Enter your message: ").upper()

def get_shift():
    while True:
        try:
            shift = int(input("Enter the shift number (0-25): "))
            if 0 <= shift <= 25:
                return shift
            print("Shift must be between 0 and 25.")
        except ValueError:
            print("Invalid input. Please enter an integer.")

def caesar_cipher(message, shift, mode):
    if mode == 'd':
        shift = -shift
    result = ''
    for char in message:
        if char.isalpha():
            offset = ord('A')
            result += chr((ord(char) - offset + shift) % 26 + offset)
        else:
            result += char
    return result

def process_file(filename, shift, mode):
    if not os.path.isfile(filename):
        print("File not found.")
        return
    with open(filename, 'r') as file:
        messages = [caesar_cipher(line.strip().upper(), shift, mode) for line in file]
    write_to_file(messages)
    print("Output written to results.txt")

def write_to_file(lines):
    with open('results.txt', 'w') as file:
        for line in lines:
            file.write(line + '\n')

def main():
    welcome()
    while True:
        mode = get_mode()
        if input("Would you like to read from a file (f) or the console (c)?: ").lower() == 'f':
            filename = input("Enter the filename: ")
            shift = get_shift()
            process_file(filename, shift, mode)
        else:
            message = get_message()
            shift = get_shift()
            print("Result:", caesar_cipher(message, shift, mode))

        if input("Would you like to encrypt or decrypt another message? (y/n): ").lower() != 'y':
            print("Thanks for using the program, goodbye!")
            break

if __name__ == "__main__":
    main()
